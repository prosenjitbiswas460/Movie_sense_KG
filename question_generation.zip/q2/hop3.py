# the following code is to generate a yes or no question for a gives node edge relation
import os
import pandas as pd
from openai import OpenAI

# please don't share the open_key to anyone. Accessing the open_key is chargeable
open_key = "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"


def get_completion(prompt, api_key, model):
    client = OpenAI(api_key=api_key)
    messages = [{"role": "user", "content": prompt}]
    response = client.chat.completions.create(
    model = model,
    messages=messages,
    seed=42,
    temperature = 0.5, # This is the degree of randomness
)
    return response.choices[0].message.content.strip()


def chat_gpt_response(prompt, api_key = open_key, model= "gpt-4o-mini"):    
    res =  get_completion(prompt, api_key, model)    
    return res

def get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3, context, movie_name, year):
    triplet = {
        "Node_1": node_1,
        "Node_2": node_2,
        "Node_3": node_3,
        "Node_4": node_4,
        "Edge_1": edge_1,
        "Edge_2": edge_2,
        "Edge_3": edge_3,
    }

    prompt = f"""
    Suppose you are good at analyzing movie context from sentences and finding out the aspect present in them.
    Consider four nodes: "Node_1", "Node_2", "Node_3", and "Node_4" and three edges: "Edge_1", "Edge_2", and "Edge_3" in the triplet delimited by triple backticks.

    - "Edge_1" describes the relationship between Node_1 and Node_2.
    - "Edge_2" describes the relationship between Node_2 and Node_3.
    - "Edge_3" describes the relationship between Node_3 and Node_4.

    Your task is to analyze the relationship between Node_1 and Node_4 based on the context provided by Edge_1, Edge_2, and Edge_3.

    - Generate a **single-correct multiple-choice** question that revolves around either Node_1 or Node_4.
    - The answer should involve information about the **other node**.
    - Provide four answer choices, where only one is correct.

    Example:
    - Node_1: "The Matrix"
    - Node_2: "Keanu Reeves"
    - Node_3: "Will Smith"
    - Node_4: "Tom Cruise"
    - Edge_1: "Keanu Reeves starred as Neo in The Matrix."
    - Edge_2: "Will Smith was originally offered the role of Neo but turned it down, which later went to Keanu Reeves."
    - Edge_3: "Tom Cruise was also considered for the role of Neo before Keanu Reeves was chosen."

    Output:
    Question: "Which actor was also considered for the role of Neo in *The Matrix*?"
    Choices:
    A) Brad Pitt
    B) Will Smith
    C) Johnny Depp
    D) Tom Cruise
    Correct Answer: D) Tom Cruise
    
    Format the response strictly as a JSON-like dictionary in the following structure:
    {{
        "question": "Your question text here",
        "options": ["Option A text", "Option B text", "Option C text", "Option D text"],
        "answer": "Correct option text"
    }}
    
    Don't allow any effect of your previous response\
    Take your time as much as you require in generating the response\
    Ensure that each option and answer is directly related to the question and avoid any redundant text.

    **Context**: "{context.capitalize()}"
    **Movie Name**: "{movie_name}"
    **Year of Release**: "{year}"


    Now apply the same logic to the following nodes and edges:

    ```{triplet}```
    """
#     print("hello I am leaving the get summary function")
    response = chat_gpt_response(prompt)
#     print(summary)
    if response:
        return response
    else:
        return "Error in generating response"
    
def parse_mcq_response(response):
    if response.startswith("{"):
        try:
            # Interpret the response as a dictionary-like format
            response_dict = eval(response)
            
            question = response_dict.get("question", "")
            options = response_dict.get("options", ["", "", "", ""])
            correct_answer = response_dict.get("answer", "")
            
            # Format question and options together in a single text block
            full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
            
            return full_question, correct_answer
        except Exception as e:
            print(f"Error parsing response: {e}")
            return "Error parsing question", "Error parsing answer"
    else:
        try:
            response = '{'+response.split("{")[1]
            response = response.split("}")[0] + "}"
            response_dict = eval(response)
                
            question = response_dict.get("question", "")
            options = response_dict.get("options", ["", "", "", ""])
            correct_answer = response_dict.get("answer", "")
            
            # Format question and options together in a single text block
            full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
            
            return full_question, correct_answer
        except Exception as e:
            print(f"Error parsing response even after second check: {e}")
            print(response)
            return "Error parsing question", "Error parsing answer"
    

def process_csv(file_path, output_folder):
    filename = os.path.splitext(os.path.basename(file_path))[0].split('_')
    context = filename[-1]
    year = filename[-2]
    movie_name = ' '.join(filename[:-2])
    
    output_file_path = os.path.join(output_folder, os.path.basename(file_path))
    if os.path.exists(output_file_path):
        print(f"Skipping {file_path} as it already exists in the output folder.")
        return
    
    df = pd.read_csv(file_path)
    
    # Check if required columns are present
    required_columns = {'node_1', 'node_2', 'node_3', 'edge_1', 'edge_2'}
    if not required_columns.issubset(df.columns):
        print(f"Error: Missing required columns in {file_path}. Found columns: {df.columns}")
        return
    
    questions_answers = []
    
    for _, row in df.iterrows():
        node_1 = row['node_1']
        node_2 = row['node_2']
        node_3 = row['node_3']
        node_4 = row['node_4']
        edge_1 = row['edge_1']
        edge_2 = row['edge_2']
        edge_3 = row['edge_3']
        
        # aspect_qa = get_aspect(node_1, node_2, edge, context, movie_name, year)
        aspect_qa = get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3, context, movie_name, year)
        if aspect_qa and "Error" not in aspect_qa:
            full_question, correct_answer = parse_mcq_response(aspect_qa)
            questions_answers.append({
                'Question & Options': full_question,
                'Correct Answer': correct_answer
            })
        else:
            print(f"Error processing row in {file_path}")
    
    output_df = pd.DataFrame(questions_answers)
    output_df.to_csv(output_file_path, index=False)
    print(f"Processed and saved: {output_file_path}")

def process_folder(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    
    for filename in os.listdir(input_folder):
        # if filename in ["Date Movie_2006_Plot.csv"]:
        if filename.endswith(".csv"):
            file_path = os.path.join(input_folder, filename)
            process_csv(file_path, output_folder)


if __name__ == '__main__':
    # node_1 = "Inception"
    # node_2 = "Leonardo DiCaprio"
    # node_3 = "Joseph Gordon-Levitt"
    # node_4 = "Christopher Nolan"
    # edge_1 = "Leonardo DiCaprio starred in Inception as the lead character, Dom Cobb."
    # edge_2 = "Joseph Gordon-Levitt played Arthur, Dom Cobbs right-hand man, in Inception."
    # edge_3 = "Christopher Nolan directed Inception, with both Leonardo DiCaprio and Joseph Gordon-Levitt playing pivotal roles."
    
    
    # # Send the triplet and get the aspect
    # aspect = get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3)
    # print(aspect)
    input_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/nodes_edges/Bollywood/Least_Popular/hop_3"
    output_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/q2hop3_Least_Popular"
    process_folder(input_folder, output_folder)