import os
import pandas as pd
from openai import OpenAI

open_key = "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"


def get_completion(prompt, api_key, model):
    client = OpenAI(api_key=api_key)
    messages = [{"role": "user", "content": prompt}]
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            seed=42,
            temperature=0.5
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error generating completion: {e}")
        return None

def chat_gpt_response(prompt, api_key=open_key, model="gpt-4o-mini"):
    return get_completion(prompt, api_key, model)

def get_aspect(node_1, node_2, edge, context, movie_name, year):
    triplet = {
        "Node_1": node_1,
        "Node_2": node_2,
        "Edge": edge
    }
    
    prompt = f"""
    Suppose you have good knowledge of Hollywood movies and are able to generate meaningful multiple-choice questions (MCQs) from the given information.

    You are provided with information about a Hollywood movie in the form of a relationship between two elements of the movie. \
    This relationship is described by two nodes ("Node_1" and "Node_2") and an "Edge" that defines how these nodes are connected. \
    Additionally, you are given the **movie context** (such as plot, theme, or characters), the **movie name**, and the **year of release**. \
    Use these details to create a multiple-choice multiple correct question (a question that must have strictly at least more than one or multiple correct answers) that incorporates \
    the movie name and release year for clarity.

    Format the response strictly as a JSON-like dictionary in the following structure:
    {{
        "question": "Your question text here",
        "options": ["Option A text", "Option B text", "Option C text", "Option D text"],
        "answer": "Correct options text"
    }}
    
    Don't allow any effect of your previous response\
    Take your time as much as you require in generating the response\
    Ensure that each option and answer is directly related to the question and avoid any redundant text.

    **Context**: "{context.capitalize()}"
    **Movie Name**: "{movie_name}"
    **Year of Release**: "{year}"

    Triplet:
    ```{triplet}```
    """
    
    response = chat_gpt_response(prompt)
    if response:
        return response
    else:
        return "Error in generating response"

def parse_mcq_response(response):
    if response.startswith("{"):
        try:
            # Interpret the response as a dictionary-like format
            response_dict = eval(response)
            
            question = response_dict.get("question", "")
            options = response_dict.get("options", ["", "", "", ""])
            correct_answer = response_dict.get("answer", "")
            
            # Format question and options together in a single text block
            full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
            
            return full_question, correct_answer
        except Exception as e:
            print(f"Error parsing response: {e}")
            return "Error parsing question", "Error parsing answer"
    else:
        try:
            response = '{'+response.split("{")[1]
            response = response.split("}")[0] + "}"
            response_dict = eval(response)
                
            question = response_dict.get("question", "")
            options = response_dict.get("options", ["", "", "", ""])
            correct_answer = response_dict.get("answer", "")
            
            # Format question and options together in a single text block
            full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
            
            return full_question, correct_answer
        except Exception as e:
            print(f"Error parsing response even after second check: {e}")
            print(response)
            return "Error parsing question", "Error parsing answer"

def process_csv(file_path, output_folder):
    filename = os.path.splitext(os.path.basename(file_path))[0].split('_')
    context = filename[-1]
    year = filename[-2]
    movie_name = ' '.join(filename[:-2])
    
    output_file_path = os.path.join(output_folder, os.path.basename(file_path))
    # if os.path.exists(output_file_path):
    #     print(f"Skipping {file_path} as it already exists in the output folder.")
    #     return
    
    df = pd.read_csv(file_path)
    
    # Check if required columns are present
    required_columns = {'node_1', 'node_2', 'edge'}
    if not required_columns.issubset(df.columns):
        print(f"Error: Missing required columns in {file_path}. Found columns: {df.columns}")
        return
    
    questions_answers = []
    
    for _, row in df.iterrows():
        node_1 = row['node_1']
        node_2 = row['node_2']
        edge = row['edge']
        
        aspect_qa = get_aspect(node_1, node_2, edge, context, movie_name, year)
        
        if aspect_qa and "Error" not in aspect_qa:
            full_question, correct_answer = parse_mcq_response(aspect_qa)
            questions_answers.append({
                'Question & Options': full_question,
                'Correct Answer': correct_answer
            })
        else:
            print(f"Error processing row in {file_path}")
    
    output_df = pd.DataFrame(questions_answers)
    output_df.to_csv(output_file_path, index=False)
    print(f"Processed and saved: {output_file_path}")

def process_folder(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    
    for filename in os.listdir(input_folder):
        if filename in [
"Ballistic_ Ecks vs. Sever_2002_Cast.csv",
"Transformers_ Age of Extinction_2014_Cast.csv",
"In the Name of the King_2008_Plot.csv",
"Epic Movie_2007_summary.csv",
"The Kissing Booth 3_2021_summary.csv",
"The Flash_2023_Plot.csv",
"Dragonball Evolution_2009_Music.csv",
"The Big Wedding_2013_Production.csv",
"The Room_2003_Production.csv",
"Moonfall_2022_Plot.csv",
"Catwoman_2004_summary.csv",
"Vampires Suck_2010_Plot.csv",
"The Haunting of Sharon Tate_2019_Production.csv",
"The Mummy_2017_Plot.csv",
"I Know Who Killed Me_2007_Cast.csv",
"Norm of the North_2016_summary.csv",
"Fantasy Island_2020_summary.csv",
"Alone in the Dark_2005_Production.csv",
"Independence Day_ Resurgence_2016_Plot.csv",
"The Master of Disguise_2002_Plot.csv",
"Firestarter_2022_Plot.csv",
"The Room_2003_Cast.csv",
"Ghost Rider_ Spirit of Vengeance_2012_Cast.csv",
"Home Sweet Home Alone_2021_Production.csv",
"Glitter_2001_Production.csv",
"The Legend of Hercules_2014_Plot.csv",
"Daddy Day Camp_2007_Cast.csv",
"The Musketeer_2001_Production.csv",
"Anacondas_ The Hunt for the Blood Orchid_2004_summary.csv",
"Street Fighter_ The Legend of Chun-Li_2009_Plot.csv",
"The Oogieloves in the Big Balloon Adventure_2012_Production.csv",
"Thunder Force_2021_summary.csv",
"Hellboy_2019_Plot.csv",
"Pearl Harbor_2001_Production.csv",
"The Musketeer_2001_Cast.csv",
"Ballistic_ Ecks vs. Sever_2002_Production.csv",
"The Goldfinch_2019_summary.csv",
"That's My Boy_2012_summary.csv",
"Epic Movie_2007_Plot.csv",
"The Legend of Hercules_2014_Cast.csv",
"Fifty Shades Freed_2018_Production.csv",
"Hellboy_2019_Production.csv",
"Street Fighter_ The Legend of Chun-Li_2009_summary.csv",
"Indiana Jones and the Dial of Destiny_2023_Cast.csv",
"Miss March_2009_Plot.csv",
"Slender Man_2018_summary.csv",
"The Love Guru_2008_summary.csv",
"Space Jam_ A New Legacy_2021_Production.csv",
"Norbit_2007_Cast.csv",
"The Roommate_2011_Production.csv",
"Rollerball_2002_summary.csv",
"Slender Man_2018_Plot.csv",
"The Wicker Man_2006_summary.csv",
"Slender Man_2018_Plot.csv",
"The Wicker Man_2006_summary.csv",
"In the Name of the King_2008_Cast.csv",
"Daddy Day Camp_2007_Production.csv",
"Gods of Egypt_2016_Plot.csv",
"Pearl Harbor_2001_Cast.csv",
"Ghost Rider_2007_Cast.csv",
"Gods of Egypt_2016_Accolades.csv",
"Pinocchio (Disney)_2022_Cast.csv",
"Ballistic_ Ecks vs. Sever_2002_Plot.csv",
"Fifty Shades of Grey_2015_Plot.csv",
"Transformers_ Age of Extinction_2014_Plot.csv",
"Fifty Shades of Grey_2015_Production.csv",
"The Mummy_2017_Production.csv",
"Thunderbirds_2004_Cast.csv",
"The Cat in the Hat_2003_Plot.csv",
"Meet the Spartans_2008_Plot.csv",
"Zookeeper_2011_Plot.csv",
"I Know Who Killed Me_2007_Plot.csv",
"Ghost Rider_2007_Production.csv",
"Deuce Bigalow_ European Gigolo_2005_Plot.csv"]:
            if filename.endswith(".csv"):
                file_path = os.path.join(input_folder, filename)
                process_csv(file_path, output_folder)

input_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/nodes_edges/Type-1/least_popular/hop_1"
output_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/q3hop1_least_popular"
process_folder(input_folder, output_folder)
