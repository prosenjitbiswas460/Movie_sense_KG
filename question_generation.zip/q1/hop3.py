# the following code is to generate a yes or no question for a gives node edge relation

from openai import OpenAI
import os
import pandas as pd

# please don't share the open_key to anyone. Accessing the open_key is chargeable
open_key = "your api key here"


def get_completion(prompt, api_key, model):
    client = OpenAI(api_key=api_key)
    messages = [{"role": "user", "content": prompt}]
    response = client.chat.completions.create(
    model = model,
    messages=messages,
    seed=42,
    temperature = 0.5, # This is the degree of randomness
)
    return response.choices[0].message.content.strip()


def chat_gpt_response(prompt, api_key = open_key, model= "gpt-4o-mini"):    
    res =  get_completion(prompt, api_key, model)    
    return res

def get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3, context, movie_name, year):
    triplet = {
        "Node_1": node_1,
        "Node_2": node_2,
        "Node_3": node_3,
        "Node_4": node_4,
        "Edge_1": edge_1,
        "Edge_2": edge_2,
        "Edge_3": edge_3,
    }

    prompt = f"""
    Suppose you are good at analyzing movie context from sentences and finding out the aspect present in them.
    Consider four nodes: "Node_1", "Node_2", "Node_3", and "Node_4" and three edges: "Edge_1", "Edge_2", and "Edge_3" in the triplet delimited by triple backticks.

    - "Edge_1" describes the relationship between Node_1 and Node_2.
    - "Edge_2" describes the relationship between Node_2 and Node_3.
    - "Edge_3" describes the relationship between Node_3 and Node_4.

    Your task is to analyze the relationship between Node_1 and Node_4, based on the context provided by Edge_1, Edge_2, and Edge_3.

    - Generate a YES or NO question that revolves around Node_1 and Node_4, without mentioning Node_2 or Node_3.
    - Ensure the question has a YES or NO answer.

    Example:
    - Node_1: "The Matrix"
    - Node_2: "Keanu Reeves"
    - Node_3: "Will Smith"
    - Node_4: "Tom Cruise"
    - Edge_1: "Keanu Reeves starred as Neo in The Matrix."
    - Edge_2: "Will Smith was originally offered the role of Neo but turned it down, which later went to Keanu Reeves."
    - Edge_3: "Tom Cruise was also considered for the role of Neo before Keanu Reeves was chosen."

    Output:
    Question: "Was Tom Cruise also considered for the role of Neo in *The Matrix*?"
    Answer: "Yes."

    
    **Context**: "{context.capitalize()}"
    **Movie Name**: "{movie_name}"
    **Year of Release**: "{year}"

    Don't allow any effect of your previous response\
    Take your time as much as you require in generating the response\
    Generate the output as follows:
    
    Format the response strictly as a JSON-like dictionary in the following structure:
    {{
        "question": "Your question text here",
        "answer": [YES/NO]
    }}


    ```{triplet}```
    """
#     print("hello I am leaving the get summary function")
    aspect = chat_gpt_response(prompt)
#     print(summary)
    return aspect

def process_csv(file_path, output_folder):
    filename = os.path.splitext(os.path.basename(file_path))[0].split('_')
    context = filename[-1]
    year = filename[-2]
    movie_name = ' '.join(filename[:-2])
    
    output_file_path = os.path.join(output_folder, os.path.basename(file_path))
    if os.path.exists(output_file_path):
        print(f"Skipping {file_path} as it already exists in the output folder.")
        return
    
    df = pd.read_csv(file_path)
    
    # Check if required columns are present
    required_columns = {'node_1', 'node_2', 'node_3', 'node_4','edge_1', 'edge_2', 'edge_3'}
    if not required_columns.issubset(df.columns):
        print(f"Error: Missing required columns in {file_path}. Found columns: {df.columns}")
        return
    
    questions_answers = []
    
    for _, row in df.iterrows():
        node_1 = row['node_1']
        node_2 = row['node_2']
        node_3 = row['node_3']
        node_4 = row['node_4']
        edge_1 = row['edge_1']
        edge_2 = row['edge_2']
        edge_3 = row['edge_3']
        
        # aspect_qa = get_aspect(node_1, node_2, edge, context, movie_name, year)
        # node_4 = row['node_4']
        print(movie_name)
        aspect_qa = get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3, context, movie_name, year)
        if aspect_qa.startswith("{"):
            try:
                aspect_qa = eval(aspect_qa)
            except Exception as e:
                print(f"Error parsing response: {e}")
                return "Error parsing question", "Error parsing answer"
        else:
            try:
                response = '{'+aspect_qa.split("{")[1]
                response = response.split("}")[0] + "}"
                aspect_qa = eval(response)
                    
                # question = response_dict.get("question", "")
                # options = response_dict.get("options", ["", "", "", ""])
                # correct_answer = response_dict.get("answer", "")
                
                # Format question and options together in a single text block
                # full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
                
                # return full_question, correct_answer
            except Exception as e:
                print(f"Error parsing response even after second check: {e}")
                print(response)
                return "Error parsing question", "Error parsing answer"

        questions_answers.append({'Question': aspect_qa['question'], 'Answer': aspect_qa['answer']})

    output_df = pd.DataFrame(questions_answers)
    output_df.to_csv(output_file_path, index=False)
    print(f"Processed and saved: {output_file_path}")


def process_folder(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    
    for filename in os.listdir(input_folder):
#         if filename in ["The Departed_2006_Plot.csv"
# , "Gangs of New York_2002_Cast.csv"
# , "Up_2009_Plot.csv"
# , "Mulholland Drive_2001_Plot.csv"
# , "Moonlight_2016_Themes.csv"
# , "Get Out_2017_Cast.csv"
# , "Pirates of the Caribbean_ The Curse of the Black Pearl_2003_Production.csv"
# , "The Incredibles_2004_Plot.csv"
# , "Spider-Man_ No Way Home_2021_Plot.csv"
# , "Batman Begins_2005_Plot.csv"
# , "Avengers_ Endgame_2019_Music.csv"
# , "Inside Out_2015_Plot.csv"
# , "Toy Story 3_2010_Plot.csv"
# , "Shrek_2001_Plot.csv"
# , "The Lord of the Rings_ The Return of the King_2003_Cast.csv"
# , "Black Panther_2018_Plot.csv"
# , "Barbie_2023_Plot.csv"
# , "Life of Pi_2012_Production.csv"
# , "Django Unchained_2012_Plot.csv"
# , "Pan's Labyrinth_2006_Production.csv"
# , "The Batman_2022_Plot.csv"
# , "Everything Everywhere All at Once_2022_Plot.csv"
# , "Pan's Labyrinth_2006_Plot.csv"
# , "Everything Everywhere All at Once_2022_Themes.csv"
# , "No Country for Old Men_2007_Plot.csv"
# , "Life of Pi_2012_Plot.csv"
# , "Birdman_2014_Plot.csv"
# , "Lost in Translation_2003_Plot.csv"
# , "Guardians of the Galaxy_2014_Plot.csv"
# , "There Will Be Blood_2007_Plot.csv"
# , "12 Years a Slave_2013_Plot.csv"
# , "Zodiac_2007_Plot.csv"
# , "Roma_2018_Plot.csv"
# , "Inception_2010_Plot.csv"
# , "The Dark Knight_2008_Plot.csv"
# , "Finding Nemo_2003_Plot.csv"
# , "Million Dollar Baby_2004_Accolades.csv"
# , "Gangs of New York_2002_Plot.csv"
# , "Deadpool_2016_Plot.csv"
# , "Soul_2020_Production.csv"
# , "Brokeback Mountain_2005_Plot.csv"
# , "Gravity_2013_Themes.csv"
# , "Slumdog Millionaire_2008_Cast.csv"
# , "Batman Begins_2005_summary.csv"
# , "Ratatouille_2007_Plot.csv"
# , "Barbie_2023_Cast.csv"
# , "X-Men_ First Class_2011_Plot.csv"
# , "The Help_2011_summary.csv"
# , "Million Dollar Baby_2004_Cast.csv"
# , "Avatar_2009_Plot.csv"
# , "No Time to Die_2021_Plot.csv"
# , "Moonlight_2016_Plot.csv"
# , "Avengers_ Infinity War_2018_Production.csv"
# , "The Pianist_2002_summary.csv"
# , "Silver Linings Playbook_2012_Plot.csv"
# , "The Incredibles_2004_Production.csv"
# , "The Prestige_2006_Themes.csv"
# , "Casino Royale_2006_Plot.csv"
# , "Whiplash_2014_summary.csv"
# , "Shutter Island_2010_Plot.csv"
# , "District 9_2009_Themes.csv"
# , "The Whale_2022_Production.csv"
# , "A Star Is Born_2018_Plot.csv"
# , "Donnie Darko_2001_Production.csv"
# , "Mystic River_2003_Plot.csv"
# , "Interstellar_2014_Plot.csv"]:
        # print("Read--->", filename)
        if filename.endswith(".csv"):
            file_path = os.path.join(input_folder, filename)
            process_csv(file_path, output_folder)


if __name__ == '__main__':
    # node_1 = "Inception"
    # node_2 = "Leonardo DiCaprio"
    # node_3 = "Joseph Gordon-Levitt"
    # node_4 = "Christopher Nolan"
    # edge_1 = "Leonardo DiCaprio starred in Inception as the lead character, Dom Cobb."
    # edge_2 = "Joseph Gordon-Levitt played Arthur, Dom Cobb's right-hand man, in Inception."
    # edge_3 = "Christopher Nolan directed Inception, with both Leonardo DiCaprio and Joseph Gordon-Levitt playing pivotal roles."
    
    
    
    # # Send the triplet and get the aspect
    # aspect = get_aspect(node_1, node_2, node_3, node_4, edge_1, edge_2, edge_3)
    # print(aspect)
    input_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/nodes_edges/Bollywood/Popular/hop_3"
    output_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/q1hop3_Popular"
    # process_folder(input_folder, output_folder)

    # send the triplet and get the aspect
    # aspect = get_aspect(node_1, node_2, node_3, edge_1, edge_2)
    # print(aspect)
    process_folder(input_folder, output_folder)