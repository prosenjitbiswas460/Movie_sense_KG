import os
import pandas as pd
from openai import OpenAI

# Ensure you keep your API keys secure
open_key = "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"

def get_completion(prompt, api_key, model):
    client = OpenAI(api_key=api_key)
    messages = [{"role": "user", "content": prompt}]
    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            seed=42,
            temperature=0.5
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"Error generating completion: {e}")
        return None

def chat_gpt_response(prompt, api_key=open_key, model="gpt-4o-mini"):    
    return get_completion(prompt, api_key, model)

def get_aspect(node_1, node_2, edge, context, movie_name, year):
    triplet = {
        "Node_1": node_1,
        "Node_2": node_2,
        "Edge": edge
    }
    
    prompt = f"""
    Suppose you have good knowledge of Hollywood movies and are able to generate meaningful questions from the given information. \

    You are provided with information about a Hollywood movie in the form of a relationship between two elements of the movie. \
    This relationship is described by two nodes ("Node_1" and "Node_2") and an "Edge" that defines how these nodes are connected. \
    Additionally, you are given below the **movie context** (such as plot, theme, or characters), the **movie name**, and the **year of release**. \
    Use these details to create questions that incorporate the movie name and release year for clarity.

    Based on the provided edge relation, context, year of release, and movie name, generate two questions:
    1. The answer to the first question should only be "NO".
    2. The answer to the second question should only be "YES".

    Don't allow any effect of your previous response\
    Take your time as much as you require in generating the response\
    Format output as strictly as a JSON-like dictionary in the following structure and HANDLE or ESCAPE all the apostrophes and double quotes \
        such that the response can be read as a dictionary:
    {   
        {
        "Question": "actual question here",
        "Answer": "YES/NO"
        },
        {
        "Question": "actual question here",
        "Answer": "YES/NO"
        }
    }

    **Context**: "{context.capitalize()}"
    **Movie Name**: "{movie_name}"
    **Year of Release**: "{year}"

    Ensure each question explicitly references the movie name "{movie_name}" and release year "{year}" so that it is clear and understandable even without additional information.


    Triplet:
    ```{triplet}```
    
    """
    
    response = chat_gpt_response(prompt)
    if response:
        return response
    else:
        return "Error in generating response"

def process_csv(file_path, output_folder):
    filename = os.path.splitext(os.path.basename(file_path))[0].split('_')
    context = filename[-1]
    year = filename[-2]
    movie_name = ' '.join(filename[:-2])

    unparsed_movies = []
    
    output_file_path = os.path.join(output_folder, os.path.basename(file_path))
    if os.path.exists(output_file_path):
        print(f"Skipping {file_path} as it already exists in the output folder.")
        return
    
    df = pd.read_csv(file_path)
    
    questions_answers = []
    
    for _, row in df.iterrows():
        node_1 = row['node_1']
        node_2 = row['node_2']
        edge = row['edge']
        
        aspect_qa = get_aspect(node_1, node_2, edge, context, movie_name, year)
        try:
            for i in eval(aspect_qa):
                try:
                    question = i["Question"]
                    answer = i["Answer"]
                    questions_answers.append({"Question": question, "Answer": answer})
                except Exception as e:
                    response = '{'+i.split("{")[1]
                    response = response.split("}")[0] + "}"
                    response_dict = eval(response)
                            
                    question = response_dict["Question"]
                    answer = response_dict["Answer"]
                    questions_answers.append({"Question": question, "Answer": answer})
        except Exception as e:
            # print(f"Error parsing response: {e}")
            if 'json' in aspect_qa:
                response = aspect_qa.split("json\n")[1]
                response = response.split("\n```")[0]
            else:
                response = aspect_qa
            response = response.replace("\"","").replace("'s","\\'s")
            # response
            try:
                response_tuple = eval(response)
            except Exception as e:
                print(e)
                continue

            for i in response_tuple:
                try:
                    question = i["Question"]
                    answer = i["Answer"]
                    questions_answers.append({"Question": question, "Answer": answer})
                except Exception as e:
                    response = '{'+i.split("{")[1]
                    response = response.split("}")[0] + "}"
                    response_dict = eval(response)
                            
                    question = response_dict["Question"]
                    answer = response_dict["Answer"]
                    questions_answers.append({"Question": question, "Answer": answer})
                
            # question = response_dict.get("question", "")
            # options = response_dict.get("options", ["", "", "", ""])
            # correct_answer = response_dict.get("answer", "")

            # unparsed_movies.append((movie_name, aspect_qa))
            # print(movie_name, aspect_qa)
            #     else:
        #         try:
                    
        #             response = '{'+aspect_qa.split("{")[1]
        #             for i in range(len(response)):
        #                 response1 = response.split("}")[0] + "}"
        #                 response_dict = eval(response1)
                            
        #                 question = response_dict.get("Question", "")
        #                 # options = response_dict.get("options", ["", "", "", ""])
        #                 answer = response_dict.get("Answer", "")
                        
        #                 # Format question and options together in a single text block
        #                 # full_question = f"{question}\nOptions:\nA. {options[0]}\nB. {options[1]}\nC. {options[2]}\nD. {options[3]}"
                        
        #                 # return question, answer
        #                 questions_answers.append({'Question': question, 'Answer': answer})
        #         except Exception as e:
        #             print(f"Error parsing response even after second check: {e}")
        #             print(response)
        #             return "Error parsing question", "Error parsing answer"

        
        # questions_answers.append({'Question': aspect_qa['Question'], 'Answer': aspect_qa['Answer']})
    
    output_df = pd.DataFrame(questions_answers)
    output_df.to_csv(output_file_path, index=False)
    print(f"Processed and saved: {output_file_path}")

def process_folder(input_folder, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    
    for filename in os.listdir(input_folder):
        if filename.endswith(".csv"):
            file_path = os.path.join(input_folder, filename)
            process_csv(file_path, output_folder)

input_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/nodes_edges/Bollywood/Popular/hop_1"
output_folder = "/Users/Prosenjit/Documents/Research/Code/movie_sense_latest/Movie_sense_KG/yuvraj/q1hop1_Popular"

process_folder(input_folder, output_folder)
